rNitro for Windows v6.0.2-Windows-x64

A lightweight system tray monitor: live CPU, temperature, RAM, SSD,
per-core stats, battery, stress test and benchmark.

Requirements
  Windows 10 or 11, 64-bit
  .NET 8 Desktop Runtime (x64) - https://dotnet.microsoft.com/download/dotnet/8.0

Running from the ZIP
  Unblock the file first: right-click rNitro.exe > Properties > Unblock,
  then double-click rNitro.exe. It lives in the system tray, not the taskbar.

  Run as administrator if you want CPU temperature readings; Windows does not
  expose thermal sensors to unelevated processes.

Uninstalling
  ZIP: quit rNitro from the tray, then delete the folder.
  MSI: Settings > Apps > Installed apps > rNitro > Uninstall.

Windows is no longer actively developed. macOS and Linux are the current
platforms. https://chopstickshq.com/rnitro/
