"""Gradio UI for the ONNX upscaler. Launch: python app.py"""
from __future__ import annotations

import tempfile
import time
from pathlib import Path

import gradio as gr

from upscaler.image_processor import upscale_image
from upscaler.models import Upscaler
from upscaler.utils import UpscalerError
from upscaler.video import COMING_SOON, RESOLUTIONS
from upscaler.video_processor import default_encoder, model_scale_for, probe, upscale_video

RES_CHOICES = [("720p", "720p"), ("1080p", "1080p"), ("1440p", "1440p"), ("4K", "4k"),
               ("8K — coming soon", "8k"), ("Native ×2 / ×4", "native")]

OUT_DIR = Path(tempfile.gettempdir()) / "video-upscaler-out"
_ENGINES: dict[tuple, Upscaler] = {}


def _engine(scale: int, tile: int, pad: int, cpu: bool, frame_size: tuple[int, int] | None = None) -> Upscaler:
    key = (scale, tile, pad, cpu, frame_size)
    if key not in _ENGINES:
        _ENGINES[key] = Upscaler(scale=scale, tile=tile, pad=pad, prefer_coreml=not cpu, frame_size=frame_size)
    return _ENGINES[key]


def _out_path(src: str, scale: int, suffix: str | None = None) -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    p = Path(src)
    return OUT_DIR / f"{p.stem}_x{scale}_{int(time.time())}{suffix or p.suffix}"


def _download(path: Path):
    return gr.DownloadButton(value=str(path), label=f"Download {path.name}", visible=True)


def run_image(src: str | None, scale: int, fmt: str, tile: int, pad: int, cpu: bool, progress=gr.Progress()):
    if not src:
        raise gr.Error("Upload an image first.")
    try:
        progress(0.1, desc="loading model")
        eng = _engine(int(scale), int(tile), int(pad), bool(cpu))
        progress(0.3, desc=f"upscaling on {eng.provider}")
        t = time.perf_counter()
        out = upscale_image(src, _out_path(src, int(scale), f".{fmt.lower()}"), engine=eng)
        progress(1.0, desc="done")
        return str(out), _download(out), f"x{scale} {fmt.upper()} via {eng.provider} in {time.perf_counter() - t:.2f}s"
    except UpscalerError as e:
        raise gr.Error(str(e)) from e


def run_video(src: str | None, res: str, scale: int, fmt: str, tile: int, pad: int, cpu: bool, encoder: str,
              quality: str, progress=gr.Progress()):
    if not src:
        raise gr.Error("Upload a video first.")
    if res in COMING_SOON:
        raise gr.Error("8K output is coming soon — pick 720p, 1080p, 1440p or 4K for now.")
    try:
        info = probe(Path(src))
        target = None if res == "native" else RESOLUTIONS[res]
        scale = model_scale_for(info.height, target) if target else int(scale)
        progress(0.0, desc="loading model")
        eng = _engine(int(scale), int(tile), int(pad), bool(cpu), (info.height, info.width))
        total = info.frames or 0
        t = time.perf_counter()

        def on_frame(n: int, _total: int) -> None:
            progress(n / total if total else 0.5, desc=f"frame {n}/{total or '?'} on {eng.provider}")

        suffix = None if fmt == "Same as input" else f".{fmt.lower()}"
        out = upscale_video(src, _out_path(src, int(scale), suffix), engine=eng, encoder=encoder or None,
                            quality=quality, target_height=target, progress=on_frame)
        el = time.perf_counter() - t
        out_h = target or info.height * eng.scale
        out_w = round(info.width * out_h / info.height / 2) * 2
        return str(out), _download(out), (
            f"{out_w}x{out_h} @ {float(info.fps):.3f}fps, model x{eng.scale}, "
            f"{total} frames in {el:.1f}s ({eng.provider}, {encoder or default_encoder()})")
    except UpscalerError as e:
        raise gr.Error(str(e)) from e


def _advanced():
    tile = gr.Slider(64, 1024, value=256, step=64, label="Tile size (px)")
    pad = gr.Slider(0, 64, value=16, step=8, label="Tile overlap (px)")
    cpu = gr.Checkbox(value=False, label="Force CPU (disable CoreML)")
    return tile, pad, cpu


with gr.Blocks(title="Video Upscaler") as demo:
    gr.Markdown("# Video Upscaler\nReal-ESRGAN via ONNX Runtime — CoreML accelerated on Apple Silicon.")

    with gr.Tabs():
        with gr.Tab("Image Upscale"):
            with gr.Row():
                with gr.Column():
                    img_in = gr.Image(type="filepath", label="Input image")
                    img_scale = gr.Radio([2, 4], value=4, label="Scale")
                    img_fmt = gr.Radio(["png", "jpg", "webp"], value="png", label="Download format")
                    with gr.Accordion("Advanced", open=False):
                        img_tile, img_pad, img_cpu = _advanced()
                    img_btn = gr.Button("Upscale image", variant="primary")
                with gr.Column():
                    img_out = gr.Image(type="filepath", label="Result", format="png")
                    img_dl = gr.DownloadButton("Download", visible=False)
                    img_log = gr.Textbox(label="Status", interactive=False)
            img_btn.click(run_image, [img_in, img_scale, img_fmt, img_tile, img_pad, img_cpu],
                          [img_out, img_dl, img_log])

        with gr.Tab("Video Upscale"):
            with gr.Row():
                with gr.Column():
                    vid_in = gr.Video(label="Input video")
                    vid_res = gr.Radio(RES_CHOICES, value="1080p", label="Output resolution",
                                       info="Height is exact; width follows the source aspect ratio.")
                    vid_fmt = gr.Radio(["mp4", "mov", "Same as input"], value="mp4", label="Download format")
                    with gr.Accordion("Advanced", open=False):
                        vid_scale = gr.Radio([2, 4], value=2, label="Model scale (used only for Native)")
                        vid_tile, vid_pad, vid_cpu = _advanced()
                        vid_enc = gr.Textbox(value=default_encoder(), label="FFmpeg encoder")
                        vid_q = gr.Textbox(value="50", label="Quality (videotoolbox q:v / libx264 crf)")
                    vid_btn = gr.Button("Upscale video", variant="primary")
                with gr.Column():
                    vid_out = gr.Video(label="Result")
                    vid_dl = gr.DownloadButton("Download", visible=False)
                    vid_log = gr.Textbox(label="Status", interactive=False)
            vid_btn.click(run_video,
                          [vid_in, vid_res, vid_scale, vid_fmt, vid_tile, vid_pad, vid_cpu, vid_enc, vid_q],
                          [vid_out, vid_dl, vid_log])


if __name__ == "__main__":
    demo.queue().launch()
