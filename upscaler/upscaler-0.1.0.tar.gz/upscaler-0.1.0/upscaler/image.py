"""CLI: python -m upscaler.image --input in.png --output out.png --scale 4"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from .image_processor import upscale_image
from .models import Upscaler
from .utils import UpscalerError


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="upscaler.image", description="Upscale a single image (ONNX Real-ESRGAN)")
    p.add_argument("--input", "-i", required=True, type=Path)
    p.add_argument("--output", "-o", required=True, type=Path)
    p.add_argument("--scale", "-s", type=int, default=4, choices=(2, 4))
    p.add_argument("--tile", type=int, default=256, help="tile size in px (lower = less RAM)")
    p.add_argument("--pad", type=int, default=16, help="tile overlap in px (higher = fewer seams)")
    p.add_argument("--cpu", action="store_true", help="force CPU execution provider")
    a = p.parse_args(argv)
    try:
        eng = Upscaler(scale=a.scale, tile=a.tile, pad=a.pad, prefer_coreml=not a.cpu)
        t = time.perf_counter()
        out = upscale_image(a.input, a.output, engine=eng)
        print(f"{out} x{a.scale} via {eng.provider} in {time.perf_counter() - t:.2f}s")
    except UpscalerError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
