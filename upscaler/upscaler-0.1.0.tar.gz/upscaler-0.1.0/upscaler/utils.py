"""Shared helpers: paths, weight download, tiling."""
from __future__ import annotations

import hashlib
import os
import urllib.request
from pathlib import Path
from typing import Iterator

import numpy as np
from PIL import Image

CACHE_DIR = Path(os.environ.get("UPSCALER_CACHE", Path.home() / ".cache" / "video-upscaler"))


class UpscalerError(RuntimeError):
    pass


def cache_dir() -> Path:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return CACHE_DIR


def download(url: str, dest: Path, sha256: str | None = None) -> Path:
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    try:
        with urllib.request.urlopen(url, timeout=60) as r, tmp.open("wb") as f:
            while chunk := r.read(1 << 20):
                f.write(chunk)
    except Exception as e:  # network/HTTP
        tmp.unlink(missing_ok=True)
        raise UpscalerError(f"failed to download {url}: {e}") from e
    if sha256:
        got = hashlib.sha256(tmp.read_bytes()).hexdigest()
        if got != sha256:
            tmp.unlink(missing_ok=True)
            raise UpscalerError(f"checksum mismatch for {url}: {got}")
    tmp.replace(dest)
    return dest


def load_image(path: Path) -> np.ndarray:
    """Return HWC uint8 RGB."""
    if not path.exists():
        raise UpscalerError(f"input not found: {path}")
    with Image.open(path) as im:
        return np.asarray(im.convert("RGB"), dtype=np.uint8)


def save_image(arr: np.ndarray, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(arr).save(path)


def to_nchw(arr: np.ndarray) -> np.ndarray:
    return (arr.astype(np.float32) / 255.0).transpose(2, 0, 1)[None]


def from_nchw(t: np.ndarray) -> np.ndarray:
    return (np.clip(t[0].transpose(1, 2, 0), 0.0, 1.0) * 255.0).round().astype(np.uint8)


def tiles(h: int, w: int, tile: int, pad: int) -> Iterator[tuple[int, int, int, int, int, int, int, int]]:
    """Yield (y0,y1,x0,x1, py0,py1,px0,px1): core box and padded read box."""
    for y0 in range(0, h, tile):
        for x0 in range(0, w, tile):
            y1, x1 = min(y0 + tile, h), min(x0 + tile, w)
            yield y0, y1, x0, x1, max(0, y0 - pad), min(h, y1 + pad), max(0, x0 - pad), min(w, x1 + pad)
