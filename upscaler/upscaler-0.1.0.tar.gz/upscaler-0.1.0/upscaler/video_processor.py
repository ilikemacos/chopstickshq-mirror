"""Video pipeline: FFmpeg decode -> tiled upscale -> FFmpeg encode + original audio."""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Callable

import numpy as np

from .models import MODELS, Upscaler
from .utils import UpscalerError

ProgressFn = Callable[[int, int], None]


@dataclass(frozen=True)
class VideoInfo:
    width: int
    height: int
    fps: Fraction
    frames: int
    has_audio: bool
    duration: float


def _require(tool: str) -> str:
    path = shutil.which(tool)
    if not path:
        raise UpscalerError(f"{tool} not found on PATH; install FFmpeg (brew install ffmpeg)")
    return path


def probe(src: Path) -> VideoInfo:
    if not src.exists():
        raise UpscalerError(f"input not found: {src}")
    out = subprocess.run(
        [_require("ffprobe"), "-v", "error", "-print_format", "json",
         "-show_streams", "-show_format", str(src)],
        capture_output=True, text=True,
    )
    if out.returncode != 0:
        raise UpscalerError(f"ffprobe failed for {src}: {out.stderr.strip()}")
    data = json.loads(out.stdout)
    streams = data.get("streams", [])
    v = next((s for s in streams if s.get("codec_type") == "video"), None)
    if v is None:
        raise UpscalerError(f"no video stream in {src}")
    fps = Fraction(v.get("avg_frame_rate") or "0/0") if "/" in str(v.get("avg_frame_rate", "")) else Fraction(0)
    if fps <= 0:
        fps = Fraction(v.get("r_frame_rate", "25/1"))
    duration = float(data.get("format", {}).get("duration") or 0.0)
    frames = int(v.get("nb_frames") or 0) or int(round(duration * float(fps)))
    return VideoInfo(
        width=int(v["width"]), height=int(v["height"]), fps=fps, frames=max(frames, 0),
        has_audio=any(s.get("codec_type") == "audio" for s in streams), duration=duration,
    )


def default_encoder() -> str:
    return "h264_videotoolbox" if sys.platform == "darwin" else "libx264"


def _decoder_cmd(src: Path) -> list[str]:
    return [_require("ffmpeg"), "-v", "error", "-nostdin", "-i", str(src),
            "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]


def model_scale_for(height: int, target_height: int) -> int:
    """Smallest available model scale that reaches target_height (4 if none does)."""
    return next((s for s in sorted(MODELS) if height * s >= target_height), max(MODELS))


def _encoder_cmd(src: Path, dst: Path, info: VideoInfo, scale: int, encoder: str, quality: str,
                 target_height: int | None = None) -> list[str]:
    cmd = [_require("ffmpeg"), "-v", "error", "-y", "-nostdin",
           "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{info.width * scale}x{info.height * scale}",
           "-r", str(info.fps), "-i", "-"]
    if info.has_audio:
        cmd += ["-i", str(src), "-map", "0:v:0", "-map", "1:a:0", "-c:a", "copy", "-shortest"]
    if target_height and target_height != info.height * scale:
        # Model works in fixed x2/x4 steps; lanczos lands exactly on the requested height.
        cmd += ["-vf", f"scale=-2:{target_height}:flags=lanczos"]
    cmd += ["-c:v", encoder, "-pix_fmt", "yuv420p"]
    cmd += ["-q:v", quality] if "videotoolbox" in encoder else ["-crf", quality, "-preset", "medium"]
    cmd += ["-r", str(info.fps), str(dst)]
    return cmd


def upscale_video(
    input_path: str | Path,
    output_path: str | Path,
    scale: int = 4,
    tile: int = 256,
    pad: int = 16,
    encoder: str | None = None,
    quality: str = "50",
    engine: Upscaler | None = None,
    progress: ProgressFn | None = None,
    prefer_coreml: bool = True,
    target_height: int | None = None,
) -> Path:
    src, dst = Path(input_path), Path(output_path)
    info = probe(src)
    eng = engine or Upscaler(scale=scale, tile=tile, pad=pad, prefer_coreml=prefer_coreml,
                             frame_size=(info.height, info.width))
    dst.parent.mkdir(parents=True, exist_ok=True)
    enc = encoder or default_encoder()
    frame_bytes = info.width * info.height * 3

    dec = subprocess.Popen(_decoder_cmd(src), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = subprocess.Popen(_encoder_cmd(src, dst, info, eng.scale, enc, quality, target_height),
                           stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    n = 0
    try:
        assert dec.stdout and out.stdin
        while True:
            raw = dec.stdout.read(frame_bytes)
            if len(raw) < frame_bytes:
                break
            frame = np.frombuffer(raw, dtype=np.uint8).reshape(info.height, info.width, 3)
            out.stdin.write(eng.upscale_array(frame).tobytes())
            n += 1
            if progress:
                progress(n, info.frames)
        out.stdin.close()
    except BrokenPipeError as e:
        raise UpscalerError(f"encoder died early: {out.stderr.read().decode(errors='replace')}") from e
    except BaseException:
        dec.kill()
        out.kill()
        raise
    finally:
        dec.stdout and dec.stdout.close()

    dec_err = (dec.stderr.read().decode(errors="replace") if dec.stderr else "").strip()
    enc_err = (out.stderr.read().decode(errors="replace") if out.stderr else "").strip()
    if dec.wait() != 0:
        raise UpscalerError(f"decode failed: {dec_err}")
    if out.wait() != 0:
        raise UpscalerError(f"encode failed: {enc_err}")
    if n == 0:
        raise UpscalerError(f"no frames decoded from {src}")
    return dst
