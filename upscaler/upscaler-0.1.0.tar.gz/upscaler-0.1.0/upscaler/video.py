"""CLI: python -m upscaler.video --input in.mp4 --output out.mp4 --scale 4"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from tqdm import tqdm

from .models import Upscaler
from .utils import UpscalerError
from .video_processor import default_encoder, model_scale_for, probe, upscale_video

RESOLUTIONS: dict[str, int] = {"720p": 720, "1080p": 1080, "1440p": 1440, "4k": 2160}
COMING_SOON: dict[str, int] = {"8k": 4320}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="upscaler.video", description="Upscale a video (ONNX Real-ESRGAN + FFmpeg)")
    p.add_argument("--input", "-i", required=True, type=Path)
    p.add_argument("--output", "-o", required=True, type=Path)
    p.add_argument("--scale", "-s", type=int, default=4, choices=(2, 4))
    p.add_argument("--resolution", "-r", default=None,
                   choices=(*RESOLUTIONS, *COMING_SOON),
                   help="target output height; overrides --scale (8k: coming soon)")
    p.add_argument("--tile", type=int, default=256)
    p.add_argument("--pad", type=int, default=16)
    p.add_argument("--encoder", default=None, help=f"ffmpeg video encoder (default: {default_encoder()})")
    p.add_argument("--quality", default="50", help="videotoolbox q:v (0-100) or libx264 crf")
    p.add_argument("--cpu", action="store_true")
    a = p.parse_args(argv)
    try:
        if a.resolution in COMING_SOON:
            raise UpscalerError(f"{a.resolution} output is coming soon; pick one of {', '.join(RESOLUTIONS)}")
        info = probe(a.input)
        target = RESOLUTIONS[a.resolution] if a.resolution else None
        scale = model_scale_for(info.height, target) if target else a.scale
        eng = Upscaler(scale=scale, tile=a.tile, pad=a.pad, prefer_coreml=not a.cpu,
                       frame_size=(info.height, info.width))
        bar = tqdm(total=info.frames or None, unit="f", desc=f"x{scale} {eng.provider}")
        t = time.perf_counter()
        upscale_video(a.input, a.output, engine=eng, encoder=a.encoder, quality=a.quality,
                      target_height=target, progress=lambda n, total: bar.update(n - bar.n))
        bar.close()
        el = time.perf_counter() - t
        out_h = target or info.height * scale
        out_w = round(info.width * out_h / info.height / 2) * 2
        print(f"{a.output} {out_w}x{out_h} @ {float(info.fps):.3f}fps in {el:.1f}s (model x{scale})")
    except UpscalerError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
