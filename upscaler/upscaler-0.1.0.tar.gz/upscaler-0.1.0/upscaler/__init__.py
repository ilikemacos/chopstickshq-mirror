"""Lightweight ONNX Real-ESRGAN upscaler (macOS / Apple Silicon friendly)."""
from .models import Upscaler, ModelSpec, MODELS  # noqa: F401
from .utils import UpscalerError  # noqa: F401

__version__ = "0.1.0"
__all__ = ["Upscaler", "ModelSpec", "MODELS", "UpscalerError"]
