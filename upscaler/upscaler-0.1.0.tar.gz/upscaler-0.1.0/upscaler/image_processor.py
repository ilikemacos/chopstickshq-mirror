"""Single-image upscale pipeline."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .models import Upscaler
from .utils import load_image, save_image


def upscale_image(
    input_path: str | Path,
    output_path: str | Path,
    scale: int = 4,
    tile: int = 256,
    engine: Upscaler | None = None,
) -> Path:
    src = Path(input_path)
    dst = Path(output_path)
    eng = engine or Upscaler(scale=scale, tile=tile)
    save_image(eng.upscale_array(load_image(src)), dst)
    return dst


def upscale_array(img: np.ndarray, scale: int = 4, tile: int = 256, engine: Upscaler | None = None) -> np.ndarray:
    return (engine or Upscaler(scale=scale, tile=tile)).upscale_array(img)
