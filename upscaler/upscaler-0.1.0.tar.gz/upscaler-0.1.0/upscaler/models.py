"""ONNX Runtime model loading + tiled inference (CoreML on macOS, CPU fallback)."""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import onnxruntime as ort

from .utils import UpscalerError, cache_dir, download, from_nchw, tiles, to_nchw

_BASE = "https://huggingface.co/yuvraj108c/ComfyUI-Upscaler-Onnx/resolve/main"


@dataclass(frozen=True)
class ModelSpec:
    name: str
    scale: int
    url: str
    sha256: str


MODELS: dict[int, ModelSpec] = {
    2: ModelSpec("2x-ESRGAN.onnx", 2, f"{_BASE}/2x-ESRGAN.onnx",
                 "f1a5e0dc1b83a7b4641078ead62fd180046fb8eb7b0231b3a29e30c071be1b6f"),
    4: ModelSpec("RealESRGAN_x4.onnx", 4, f"{_BASE}/RealESRGAN_x4.onnx",
                 "0419b536f5bdadaf984b0a3777307dd83e2487e7e13d65a68147b8443f021675"),
}


def providers(prefer_coreml: bool = True) -> list:
    avail = ort.get_available_providers()
    out: list = []
    if prefer_coreml and sys.platform == "darwin" and "CoreMLExecutionProvider" in avail:
        # MLProgram + FP32 keeps dynamic shapes working on Apple Silicon.
        out.append(("CoreMLExecutionProvider", {"ModelFormat": "MLProgram", "MLComputeUnits": "ALL"}))
    out.append("CPUExecutionProvider")
    return out


class Upscaler:
    """Tiled ESRGAN inference session."""

    def __init__(self, scale: int = 4, tile: int = 256, pad: int = 16, prefer_coreml: bool = True,
                 frame_size: tuple[int, int] | None = None) -> None:
        """frame_size=(h, w) sizes the session to whole frames when they fit in one tile."""
        if scale not in MODELS:
            raise UpscalerError(f"unsupported scale {scale}; choose one of {sorted(MODELS)}")
        if tile < 32:
            raise UpscalerError("tile must be >= 32")
        self.spec = MODELS[scale]
        self.scale = scale
        if frame_size and max(frame_size) <= tile:
            # Whole frame fits: one inference per frame, no padding, no seams.
            self.patch_h, self.patch_w = frame_size
            self.tile, self.pad = max(frame_size), 0
        else:
            self.tile, self.pad = tile, pad
            self.patch_h = self.patch_w = tile + 2 * pad
        path = download(self.spec.url, cache_dir() / self.spec.name, self.spec.sha256)
        opts = ort.SessionOptions()
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        opts.log_severity_level = 3
        # CoreML rejects unbounded dims; freeze them so the ANE/GPU path is usable.
        for dim, val in (("batch_size", 1), ("width", self.patch_h), ("height", self.patch_w)):
            opts.add_free_dimension_override_by_name(dim, val)
        try:
            self.session = ort.InferenceSession(str(path), opts, providers=providers(prefer_coreml))
        except Exception as e:
            raise UpscalerError(f"failed to load model {path}: {e}") from e
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name

    @property
    def provider(self) -> str:
        return self.session.get_providers()[0]

    def _infer(self, patch: np.ndarray) -> np.ndarray:
        """Run one patch, edge-padded to the session's fixed input size."""
        ph, pw = patch.shape[:2]
        if ph > self.patch_h or pw > self.patch_w:
            raise UpscalerError(f"patch {ph}x{pw} exceeds fixed size {self.patch_h}x{self.patch_w}")
        if (ph, pw) != (self.patch_h, self.patch_w):
            patch = np.pad(patch, ((0, self.patch_h - ph), (0, self.patch_w - pw), (0, 0)), mode="edge")
        out = self.session.run([self.output_name], {self.input_name: to_nchw(patch)})[0]
        return from_nchw(out)[: ph * self.scale, : pw * self.scale]

    def upscale_array(self, img: np.ndarray) -> np.ndarray:
        """HWC uint8 RGB in, HWC uint8 RGB out at self.scale."""
        if img.ndim != 3 or img.shape[2] != 3:
            raise UpscalerError(f"expected HxWx3 RGB array, got {img.shape}")
        h, w = img.shape[:2]
        s = self.scale
        out = np.empty((h * s, w * s, 3), dtype=np.uint8)
        for y0, y1, x0, x1, py0, py1, px0, px1 in tiles(h, w, self.tile, self.pad):
            up = self._infer(img[py0:py1, px0:px1])
            oy0, ox0 = (y0 - py0) * s, (x0 - px0) * s
            out[y0 * s:y1 * s, x0 * s:x1 * s] = up[oy0:oy0 + (y1 - y0) * s, ox0:ox0 + (x1 - x0) * s]
        return out
