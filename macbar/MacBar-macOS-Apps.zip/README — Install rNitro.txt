rNitro macOS Apps — Stable + Beta
  rNitro-Stable.app from rNitro-v1.2.9-Final.zip
  rNitro-Beta.app from rNitro-v1.2.13.zip
Install only one at a time.
