rNitro v1.2.8-Final
===================

INSTALLATION
------------
1. Double-click this ZIP file to extract rNitro.app
2. Drag rNitro.app into your Applications folder
   (Finder → Applications, or ~/Applications)
3. Open Applications and double-click rNitro
4. rNitro lives in your menu bar (top-right). Click the icon to open the monitor.

FIRST LAUNCH
------------
If macOS says the app cannot be opened:
  • Right-click rNitro.app → Open → Open (one time only), or
  • System Settings → Privacy & Security → Open Anyway

REQUIREMENTS
------------
  • macOS 12 Monterey or later
  • Apple Silicon Mac (arm64)
  • Launch at Login requires macOS 13+

UNINSTALL
---------
Drag rNitro.app from Applications to Trash.

ALTERNATIVE: COMPILE FROM SOURCE
--------------------------------
The .sh installer on https://getrnitro.netlify.app/ compiles rNitro on your Mac
(~30 seconds) and installs to ~/Applications/rNitro.app.

SUPPORT
-------
https://getrnitro.netlify.app/
