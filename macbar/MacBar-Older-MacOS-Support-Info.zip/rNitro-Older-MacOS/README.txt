rNitro — Older macOS support
================================

SUPPORTED
  • macOS 14.0 Sonoma or later (including Sequoia and newer)
  • Apple Silicon or Intel (universal build when available)
  Download: https://chopstickshq.com/rnitro/

NOT SUPPORTED (no working app binary)
  • macOS 11 Big Sur (including 11.7.6)
  • macOS 12 Monterey
  • macOS 13 Ventura
  • Mac OS X 10.0–10.15
  • Mac OS 8 / Mac OS 9 (classic)

Why?
  Current rNitro is a modern SwiftUI app. Compiling it for older systems fails
  because it uses APIs only available on macOS 14+. Mac OS 8/9 is a completely
  different platform (classic Mac OS).

What to do on older Macs
  • Upgrade to macOS 14+ when your hardware allows, or
  • Use a newer Mac for rNitro

This ZIP is information only. It is not an installer.
Source: https://github.com/ilikemacos/rNitro
