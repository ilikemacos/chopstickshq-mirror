#version 410 core
// HUD: flat color with alpha (blending is enabled for the HUD pass).

out vec4 FragColor;

uniform vec4 uColor;

void main() {
    FragColor = uColor;
}
