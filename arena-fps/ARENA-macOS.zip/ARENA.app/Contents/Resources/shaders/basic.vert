#version 410 core
// World-geometry vertex shader.
// Two paths share this shader:
//   - normal draws:    uModel holds the model matrix, uUseInstanceModel == 0
//   - instanced draws: per-instance model matrix arrives in attributes 2..5
//                      (a mat4 eats 4 consecutive attribute slots)

layout(location = 0) in vec3 aPos;      // object-space position
layout(location = 1) in vec3 aNormal;   // object-space normal
layout(location = 2) in mat4 aInstanceModel;
// Terrain only: sun visibility baked at generation time (1 = open sky,
// 0 = in the shadow of a hill). Every other draw leaves this attribute
// disabled, so it reads as 0 — which is why the fragment shader applies it
// only for the terrain material.
layout(location = 6) in float aSun;

uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProj;
uniform int  uUseInstanceModel;

out vec3 vWorldPos;
out vec3 vNormal;
out float vSun;

void main() {
    mat4 model = (uUseInstanceModel == 1) ? aInstanceModel : uModel;
    vec4 world = model * vec4(aPos, 1.0);
    vWorldPos  = world.xyz;
    // note: fine for uniform scale; a proper inverse-transpose would be
    // needed for non-uniform scale, but all our boxes ARE non-uniformly
    // scaled axis-aligned boxes whose normals stay axis-aligned anyway,
    // so normalize(mat3(model) * n) still points the right way.
    vNormal = normalize(mat3(model) * aNormal);
    vSun = aSun;
    gl_Position = uProj * uView * world;
}
