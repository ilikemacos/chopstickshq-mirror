#version 410 core
// HUD: screen-space colored quads. Positions come in already in pixels;
// uProj is an orthographic projection over the framebuffer.

layout(location = 0) in vec2 aPos;

uniform mat4 uProj;

void main() {
    gl_Position = uProj * vec4(aPos, 0.0, 1.0);
}
