import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { Prefs, Tab, Workspace } from './types'

const HOME = 'cs://home'
const SEARCH = 'https://duckduckgo.com/?q='

function uid() { return crypto.randomUUID() }

function normalizeUrl(raw: string) {
  const t = raw.trim()
  if (!t || t === HOME) return HOME
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(t)) return t
  if (t.includes(' ') || !t.includes('.')) return SEARCH + encodeURIComponent(t)
  return `https://${t}`
}

function displayUrl(url: string) {
  return url === HOME ? '' : url.replace(/^https:\/\//, '')
}

function newTab(workspaceId: string, url = HOME, extra: Partial<Tab> = {}): Tab {
  return {
    id: uid(), workspaceId, url,
    title: url === HOME ? 'New Tab' : url,
    favicon: '', pinned: false, essential: false,
    partition: `persist:ws-${workspaceId}`,
    ...extra
  }
}

const GUEST_HOOK = `(function(){
  if (window.__csHook) return; window.__csHook = true;
  document.addEventListener('click', function(e){
    var a = e.target && e.target.closest && e.target.closest('a[href]');
    if (!a || !e.altKey) return;
    e.preventDefault(); e.stopPropagation();
    console.log('CS::GLANCE::' + a.href);
  }, true);
  document.addEventListener('mouseup', function(){
    var t = (window.getSelection && window.getSelection().toString()) || '';
    if (t.trim()) console.log('CS::SELECT::' + t.slice(0,4000));
  });
})();`

export default function App() {
  const [prefs, setPrefs] = useState<Prefs | null>(null)
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [wsId, setWsId] = useState('default')
  const [tabs, setTabs] = useState<Tab[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [splitIds, setSplitIds] = useState<string[]>([])
  const [urlDraft, setUrlDraft] = useState('')
  const [compactEdge, setCompactEdge] = useState(false)
  const [aiOpen, setAiOpen] = useState(false)
  const [aiFloat, setAiFloat] = useState(false)
  const [aiMsgs, setAiMsgs] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    { role: 'assistant', content: 'cs.ai is ready. Chromium session context is on.' }
  ])
  const [aiDraft, setAiDraft] = useState('')
  const [aiBusy, setAiBusy] = useState(false)
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('cs.ai.key') || '')
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [glanceUrl, setGlanceUrl] = useState<string | null>(null)
  const [ctx, setCtx] = useState<{ x: number; y: number; tab: Tab } | null>(null)
  const [selection, setSelection] = useState('')
  const [findOpen, setFindOpen] = useState(false)
  const [findQ, setFindQ] = useState('')
  const [panel, setPanel] = useState<'history' | 'bookmarks' | null>(null)
  const [history, setHistory] = useState<{ title: string; url: string }[]>([])
  const [bookmarks, setBookmarks] = useState<{ title: string; url: string }[]>(() => {
    try { return JSON.parse(localStorage.getItem('cs.bookmarks') || '[]') } catch { return [] }
  })
  const closed = useRef<Tab[]>([])
  const webviews = useRef<Record<string, Electron.WebviewTag>>({})
  const bound = useRef<Set<string>>(new Set())
  const activeIdRef = useRef<string | null>(null)
  const tabsRef = useRef<Tab[]>([])
  const wsIdRef = useRef('default')
  const prefsRef = useRef<Prefs | null>(null)
  const splitRef = useRef<string[]>([])
  activeIdRef.current = activeId
  tabsRef.current = tabs
  wsIdRef.current = wsId
  prefsRef.current = prefs
  splitRef.current = splitIds

  const active = tabs.find((t) => t.id === activeId) ?? null
  const wsTabs = tabs.filter((t) => t.workspaceId === wsId)
  const essentials = wsTabs.filter((t) => t.essential)
  const rest = wsTabs.filter((t) => !t.essential).sort((a, b) => Number(b.pinned) - Number(a.pinned))
  const ws = workspaces.find((w) => w.id === wsId)
  const wv = () => (activeId ? webviews.current[activeId] : undefined)

  useEffect(() => {
    void (async () => {
      const p = await window.cs.prefs.get()
      const w = await window.cs.workspaces.get()
      setPrefs(p)
      setWorkspaces(w)
      const first = newTab(w[0]?.id ?? 'default')
      setTabs([first])
      setActiveId(first.id)
      document.documentElement.dataset.theme = p.theme
      document.documentElement.style.setProperty('--accent', w[0]?.accent ?? '#7eb8da')
    })()
    const offS = window.cs.onShortcut((name, extra) => handleShortcut(name, extra))
    const offC = window.cs.onCompactEdge(setCompactEdge)
    return () => { offS(); offC() }
  }, [])

  useEffect(() => { if (prefs) document.documentElement.dataset.theme = prefs.theme }, [prefs?.theme])
  useEffect(() => { if (ws?.accent) document.documentElement.style.setProperty('--accent', ws.accent) }, [ws])
  useEffect(() => { if (active) setUrlDraft(displayUrl(active.url)) }, [activeId, active?.url])
  useEffect(() => { localStorage.setItem('cs.bookmarks', JSON.stringify(bookmarks)) }, [bookmarks])

  const patchPrefs = async (patch: Partial<Prefs>) => setPrefs(await window.cs.prefs.set(patch))

  const addTab = (url?: string) => {
    const t = newTab(wsIdRef.current, url)
    setTabs((prev) => [...prev, t])
    setActiveId(t.id)
  }

  const closeTab = (id: string | null) => {
    if (!id) return
    const tab = tabsRef.current.find((t) => t.id === id)
    if (tab) closed.current = [tab, ...closed.current].slice(0, 20)
    setTabs((prev) => {
      const next = prev.filter((t) => t.id !== id)
      if (activeIdRef.current === id) {
        const same = next.filter((t) => t.workspaceId === wsIdRef.current)
        setActiveId(same.at(-1)?.id ?? next[0]?.id ?? null)
      }
      return next.length ? next : [newTab(wsIdRef.current)]
    })
    setSplitIds((s) => s.filter((x) => x !== id))
    delete webviews.current[id]
  }

  const updateTab = (id: string, patch: Partial<Tab>) => {
    setTabs((prev) => prev.map((t) => (t.id === id ? { ...t, ...patch } : t)))
  }

  const navigate = (id: string, raw: string) => {
    const url = normalizeUrl(raw)
    updateTab(id, { url, title: url === HOME ? 'New Tab' : url })
    const el = webviews.current[id]
    if (el && url !== HOME) el.loadURL(url)
  }

  const cycle = (dir: number) => {
    const list = tabsRef.current.filter((t) => t.workspaceId === wsIdRef.current)
    const i = list.findIndex((t) => t.id === activeIdRef.current)
    if (i < 0 || !list.length) return
    const n = list[(i + dir + list.length) % list.length]
    setActiveId(n.id)
  }

  function handleShortcut(name: string, extra?: unknown) {
    const id = activeIdRef.current
    const view = id ? webviews.current[id] : undefined
    switch (name) {
      case 'new-tab': addTab(); break
      case 'close-tab': closeTab(id); break
      case 'reopen-tab': {
        const t = closed.current.shift()
        if (t) {
          const n = { ...t, id: uid() }
          setTabs((p) => [...p, n]); setActiveId(n.id)
        }
        break
      }
      case 'focus-url': document.querySelector<HTMLInputElement>('.omnibox input')?.focus(); break
      case 'reload': view?.reload(); break
      case 'hard-reload': view?.reloadIgnoringCache(); break
      case 'stop': view?.stop(); break
      case 'back': view?.goBack(); break
      case 'forward': view?.goForward(); break
      case 'home': if (id) navigate(id, HOME); break
      case 'zoom-in': view?.setZoomFactor((view.getZoomFactor?.() ?? 1) + 0.1); break
      case 'zoom-out': view?.setZoomFactor(Math.max(0.3, (view.getZoomFactor?.() ?? 1) - 0.1)); break
      case 'zoom-reset': view?.setZoomFactor(1); break
      case 'print': void view?.print(); break
      case 'save': if (view) void view.downloadURL(view.getURL()); break
      case 'devtools': view?.openDevTools(); break
      case 'find': setFindOpen(true); break
      case 'find-next': view?.findInPage(findQ || ' ', { forward: true }); break
      case 'find-prev': view?.findInPage(findQ || ' ', { forward: false }); break
      case 'compact': void window.cs.prefs.set({ compact: !prefsRef.current?.compact }).then(setPrefs); break
      case 'toggle-sidebar': void window.cs.prefs.set({ sidebarCollapsed: !prefsRef.current?.sidebarCollapsed }).then(setPrefs); break
      case 'ai': setAiOpen((v) => !v); break
      case 'split': {
        const current = tabsRef.current.filter((t) => t.workspaceId === wsIdRef.current)
        if (splitRef.current.length >= 2) setSplitIds(id ? [id] : [])
        else setSplitIds(current.slice(0, 2).map((t) => t.id))
        break
      }
      case 'next-tab': cycle(1); break
      case 'prev-tab': cycle(-1); break
      case 'tab-n': {
        const n = Number(extra)
        const list = tabsRef.current.filter((t) => t.workspaceId === wsIdRef.current)
        if (list[n - 1]) setActiveId(list[n - 1].id)
        break
      }
      case 'tab-last': {
        const list = tabsRef.current.filter((t) => t.workspaceId === wsIdRef.current)
        if (list.length) setActiveId(list[list.length - 1].id)
        break
      }
      case 'bookmark': {
        const t = tabsRef.current.find((x) => x.id === id)
        if (t && t.url !== HOME) setBookmarks((b) => [{ title: t.title, url: t.url }, ...b])
        break
      }
      case 'bookmark-all':
        setBookmarks((b) => [
          ...tabsRef.current.filter((t) => t.url !== HOME).map((t) => ({ title: t.title, url: t.url })),
          ...b
        ])
        break
      case 'bookmarks': setPanel((p) => (p === 'bookmarks' ? null : 'bookmarks')); break
      case 'history': setPanel((p) => (p === 'history' ? null : 'history')); break
      default: break
    }
  }

  const sendAi = async (prompt: string) => {
    const text = prompt.trim()
    if (!text || aiBusy) return
    setAiDraft('')
    setAiMsgs((m) => [...m, { role: 'user', content: text }])
    setAiBusy(true)
    const open = wsTabs.map((t) => `- ${t.title} (${t.url})`).join('\n')
    const system = `You are cs.ai in cs.browser (Chromium). No telemetry.\nActive: ${active?.title} ${active?.url}\nSelection: ${selection || '(none)'}\nTabs:\n${open}`
    try {
      if (!apiKey) {
        setAiMsgs((m) => [...m, { role: 'assistant', content: `Local mode. Page: ${active?.title} (${active?.url}). Add an API key in Settings.` }])
        return
      }
      const reply = await window.cs.aiComplete({
        apiKey,
        messages: [{ role: 'system', content: system }, { role: 'user', content: text }]
      })
      setAiMsgs((m) => [...m, { role: 'assistant', content: reply || '(empty)' }])
    } catch (e) {
      setAiMsgs((m) => [...m, { role: 'assistant', content: `Failed: ${(e as Error).message}` }])
    } finally { setAiBusy(false) }
  }

  const bindWebview = useCallback((id: string, el: Electron.WebviewTag | null) => {
    if (!el) return
    webviews.current[id] = el
    if (bound.current.has(id)) return
    bound.current.add(id)
    el.addEventListener('dom-ready', () => { void el.executeJavaScript(GUEST_HOOK).catch(() => undefined) })
    el.addEventListener('page-title-updated', (e) => updateTab(id, { title: e.title }))
    el.addEventListener('page-favicon-updated', (e) => updateTab(id, { favicon: e.favicons[0] ?? '' }))
    el.addEventListener('did-navigate', (e) => {
      updateTab(id, { url: e.url })
      setHistory((h) => [{ title: el.getTitle(), url: e.url }, ...h].slice(0, 100))
    })
    el.addEventListener('did-navigate-in-page', (e) => updateTab(id, { url: e.url }))
    el.addEventListener('console-message', (e) => {
      if (e.message.startsWith('CS::GLANCE::')) setGlanceUrl(e.message.slice(12))
      if (e.message.startsWith('CS::SELECT::')) setSelection(e.message.slice(12))
    })
  }, [])

  const panes = useMemo(() => {
    const ids = splitIds.filter((id) => tabs.some((t) => t.id === id))
    if (ids.length >= 2) return ids
    return activeId ? [activeId] : []
  }, [splitIds, tabs, activeId])

  if (!prefs) return null
  const sidebarHidden = prefs.compact && !compactEdge
  const sidebarFloat = prefs.compact && compactEdge

  return (
    <div className="app" onClick={() => setCtx(null)}>
      <aside className={`sidebar ${prefs.sidebarCollapsed ? 'collapsed' : ''} ${sidebarHidden ? 'compact-hidden' : ''} ${sidebarFloat ? 'compact-float' : ''}`}>
        <div className="omnibox">
          <button className="icon-btn" onClick={() => wv()?.goBack()}>‹</button>
          <button className="icon-btn" onClick={() => wv()?.goForward()}>›</button>
          <input value={urlDraft} placeholder="Search or enter address"
            onChange={(e) => setUrlDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && activeId) navigate(activeId, urlDraft) }} />
          <button className="icon-btn" onClick={() => setAiOpen((v) => !v)}>✦</button>
        </div>
        {essentials.length > 0 && (
          <div className="essentials">
            {essentials.map((t) => (
              <button key={t.id} className="dot" onClick={() => setActiveId(t.id)}>
                {t.favicon ? <img className="favicon" src={t.favicon} alt="" /> : t.title[0]}
              </button>
            ))}
          </div>
        )}
        <div className="section-label">Tabs</div>
        <div className="tab-list">
          {rest.map((t) => (
            <div key={t.id} className={`tab ${t.id === activeId ? 'active' : ''}`}
              onClick={() => setActiveId(t.id)}
              onContextMenu={(e) => { e.preventDefault(); setCtx({ x: e.clientX, y: e.clientY, tab: t }) }}>
              {t.favicon ? <img className="favicon" src={t.favicon} alt="" /> : <span className="favicon" />}
              {!prefs.sidebarCollapsed && <span className="tab-title">{t.title}</span>}
              <button className="close" onClick={(e) => { e.stopPropagation(); closeTab(t.id) }}>×</button>
            </div>
          ))}
        </div>
        <button className="tab" onClick={() => addTab()}>＋ New Tab</button>
        <div className="workspace-bar">
          {workspaces.map((w) => (
            <button key={w.id} className={`ws ${w.id === wsId ? 'active' : ''}`} onClick={() => {
              setWsId(w.id)
              const existing = tabs.find((t) => t.workspaceId === w.id)
              if (existing) setActiveId(existing.id)
              else { const t = newTab(w.id); setTabs((p) => [...p, t]); setActiveId(t.id) }
              setSplitIds([])
            }}>{w.icon}</button>
          ))}
          <button className="ws" onClick={() => setSettingsOpen(true)}>⚙</button>
        </div>
      </aside>

      <main className="stage">
        {findOpen && (
          <div className="findbar" onClick={(e) => e.stopPropagation()}>
            <input autoFocus value={findQ} placeholder="Find in page"
              onChange={(e) => { setFindQ(e.target.value); wv()?.findInPage(e.target.value) }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') wv()?.findInPage(findQ, { forward: !e.shiftKey })
                if (e.key === 'Escape') { setFindOpen(false); wv()?.stopFindInPage('clearSelection') }
              }} />
            <button className="chip" onClick={() => wv()?.findInPage(findQ, { forward: false })}>↑</button>
            <button className="chip" onClick={() => wv()?.findInPage(findQ, { forward: true })}>↓</button>
            <button className="chip" onClick={() => setFindOpen(false)}>×</button>
          </div>
        )}
        {panel && (
          <div className="settings" style={{ inset: '48px 24px auto auto', width: 360, height: 420 }}>
            <h3>{panel}</h3>
            {(panel === 'history' ? history : bookmarks).map((h, i) => (
              <button key={i} className="tab" onClick={() => { if (activeId) navigate(activeId, h.url); setPanel(null) }}>
                <span className="tab-title">{h.title}</span>
              </button>
            ))}
            <button className="chip" onClick={() => setPanel(null)}>Close</button>
          </div>
        )}
        {panes.map((id) => {
          const tab = tabs.find((t) => t.id === id)
          if (!tab) return null
          return (
            <div key={id} className="pane">
              {panes.length > 1 && <button className="pane-close" onClick={() => setSplitIds(panes.filter((p) => p !== id))}>×</button>}
              {tab.url === HOME ? (
                <Home onGo={(q) => navigate(tab.id, q)} />
              ) : (
                <webview
                  ref={(el: Electron.WebviewTag | null) => bindWebview(tab.id, el)}
                  src={tab.url}
                  partition={tab.partition}
                  allowpopups="true"
                />
              )}
            </div>
          )
        })}
        {glanceUrl && (
          <div className="glance-scrim" onClick={() => setGlanceUrl(null)}>
            <div className="glance" onClick={(e) => e.stopPropagation()}>
              <div className="glance-bar">
                <button onClick={() => setGlanceUrl(null)}>Close</button>
                <button onClick={() => { addTab(glanceUrl); setGlanceUrl(null) }}>Expand</button>
                <button onClick={() => {
                  const t = newTab(wsId, glanceUrl)
                  setTabs((p) => [...p, t])
                  setSplitIds((s) => [...(s.length ? s : activeId ? [activeId] : []), t.id].slice(0, 3))
                  setGlanceUrl(null)
                }}>Split</button>
              </div>
              <webview src={glanceUrl} partition={active?.partition} allowpopups="true" style={{ width: '100%', height: '100%' }} />
            </div>
          </div>
        )}
      </main>

      {aiOpen && (
        <section className={`ai-panel ${aiFloat ? 'floating' : ''}`}>
          <div className="ai-head">
            <span>cs.ai</span>
            <div>
              <button className="icon-btn" onClick={() => setAiFloat((v) => !v)}>▢</button>
              <button className="icon-btn" onClick={() => setAiOpen(false)}>×</button>
            </div>
          </div>
          <div className="ai-msgs">
            {aiMsgs.map((m, i) => <div key={i} className={`msg ${m.role}`}>{m.content}</div>)}
            {aiBusy && <div className="msg assistant">Thinking…</div>}
          </div>
          <div style={{ display: 'flex', gap: 6, padding: '0 10px 8px' }}>
            <button className="chip" onClick={() => void sendAi(`Summarize: ${active?.title} ${active?.url}`)}>Summarize</button>
            <button className="chip" onClick={() => void sendAi('Brief my open tabs.')}>Session</button>
          </div>
          <div className="ai-compose">
            <textarea value={aiDraft} onChange={(e) => setAiDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendAi(aiDraft) } }} />
            <button className="icon-btn" onClick={() => void sendAi(aiDraft)}>↑</button>
          </div>
        </section>
      )}

      {settingsOpen && (
        <div className="settings">
          <h2>Settings</h2>
          <label><input type="checkbox" checked={prefs.theme === 'dark'} onChange={(e) => void patchPrefs({ theme: e.target.checked ? 'dark' : 'light' })} /> Dark mode</label>
          <label><input type="checkbox" checked={prefs.compact} onChange={(e) => void patchPrefs({ compact: e.target.checked })} /> Compact mode</label>
          <label><input type="checkbox" checked={prefs.sidebarCollapsed} onChange={(e) => void patchPrefs({ sidebarCollapsed: e.target.checked })} /> Collapse sidebar</label>
          <label><input type="checkbox" checked={prefs.httpsOnly} onChange={(e) => void patchPrefs({ httpsOnly: e.target.checked })} /> HTTPS-only</label>
          <label><input type="checkbox" checked={prefs.blockTrackers} onChange={(e) => void patchPrefs({ blockTrackers: e.target.checked })} /> Block trackers</label>
          <p style={{ color: 'var(--muted)', fontSize: 12 }}>Engine: Chromium. Telemetry off. ⌘S saves the page; compact is ⌥⌘S.</p>
          <h2>cs.ai</h2>
          <input type="text" value={prefs.apiBaseURL} onChange={(e) => void patchPrefs({ apiBaseURL: e.target.value })} />
          <input type="text" value={prefs.apiModel} onChange={(e) => void patchPrefs({ apiModel: e.target.value })} />
          <input type="password" value={apiKey} onChange={(e) => { setApiKey(e.target.value); localStorage.setItem('cs.ai.key', e.target.value) }} />
          <button className="chip" onClick={() => setSettingsOpen(false)}>Done</button>
        </div>
      )}

      {ctx && (
        <div className="ctx" style={{ left: ctx.x, top: ctx.y }} onClick={(e) => e.stopPropagation()}>
          <button onClick={() => { updateTab(ctx.tab.id, { pinned: !ctx.tab.pinned }); setCtx(null) }}>{ctx.tab.pinned ? 'Unpin' : 'Pin'}</button>
          <button onClick={() => { updateTab(ctx.tab.id, { essential: !ctx.tab.essential }); setCtx(null) }}>Essentials</button>
          <button onClick={() => { addTab(ctx.tab.url); setCtx(null) }}>Duplicate</button>
          <button onClick={() => { setSplitIds((s) => [...new Set([...(s.length ? s : activeId ? [activeId] : []), ctx.tab.id])]); setCtx(null) }}>Split</button>
          <button onClick={() => { setGlanceUrl(ctx.tab.url); setCtx(null) }}>Glance</button>
          <button onClick={() => { closeTab(ctx.tab.id); setCtx(null) }}>Close</button>
        </div>
      )}
    </div>
  )
}

function Home({ onGo }: { onGo: (q: string) => void }) {
  const [q, setQ] = useState('')
  return (
    <div className="home">
      <div>
        <h1>cs.browser</h1>
        <p style={{ color: '#9a9aa3' }}>Chromium · vertical tabs · cs.ai</p>
        <input className="home-search" placeholder="Search the web" value={q}
          onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') onGo(q) }} />
      </div>
    </div>
  )
}
