export {}

declare global {
  interface Window {
    cs: {
      prefs: {
        get: () => Promise<Prefs>
        set: (patch: Partial<Prefs>) => Promise<Prefs>
      }
      workspaces: {
        get: () => Promise<Workspace[]>
        set: (list: Workspace[]) => Promise<Workspace[]>
      }
      openExternal: (url: string) => Promise<void>
      aiComplete: (payload: {
        messages: { role: string; content: string }[]
        apiKey: string
      }) => Promise<string>
      onShortcut: (fn: (name: string, extra?: unknown) => void) => () => void
      onCompactEdge: (fn: (hover: boolean) => void) => () => void
    }
  }
  namespace React {
    namespace JSX {
      interface IntrinsicElements {
        webview: React.DetailedHTMLProps<
          React.HTMLAttributes<HTMLElement> & { src?: string; partition?: string; allowpopups?: string },
          HTMLElement
        >
      }
    }
  }
}

export interface Prefs {
  theme: 'dark' | 'light'
  compact: boolean
  sidebarCollapsed: boolean
  httpsOnly: boolean
  blockTrackers: boolean
  apiBaseURL: string
  apiModel: string
}

export interface Workspace {
  id: string
  name: string
  icon: string
  accent: string
}

export interface Tab {
  id: string
  workspaceId: string
  url: string
  title: string
  favicon: string
  pinned: boolean
  essential: boolean
  partition: string
}
