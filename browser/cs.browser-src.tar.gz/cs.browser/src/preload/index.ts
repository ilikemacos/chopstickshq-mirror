import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('cs', {
  prefs: {
    get: () => ipcRenderer.invoke('prefs:get'),
    set: (patch: Record<string, unknown>) => ipcRenderer.invoke('prefs:set', patch)
  },
  workspaces: {
    get: () => ipcRenderer.invoke('workspaces:get'),
    set: (list: unknown) => ipcRenderer.invoke('workspaces:set', list)
  },
  openExternal: (url: string) => ipcRenderer.invoke('open-external', url),
  aiComplete: (payload: { messages: { role: string; content: string }[]; apiKey: string }) =>
    ipcRenderer.invoke('ai:complete', payload),
  onShortcut: (fn: (name: string, extra?: unknown) => void) => {
    const listener = (_: unknown, name: string, extra?: unknown) => fn(name, extra)
    ipcRenderer.on('shortcut', listener)
    return () => ipcRenderer.removeListener('shortcut', listener)
  },
  onCompactEdge: (fn: (hover: boolean) => void) => {
    const listener = (_: unknown, hover: boolean) => fn(hover)
    ipcRenderer.on('compact-edge', listener)
    return () => ipcRenderer.removeListener('compact-edge', listener)
  }
})
