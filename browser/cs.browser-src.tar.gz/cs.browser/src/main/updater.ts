import { app, dialog, BrowserWindow } from 'electron'
import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { createWriteStream } from 'node:fs'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { pipeline } from 'node:stream/promises'
import { Readable } from 'node:stream'

export const DEFAULT_FEED = 'https://chopstickshq.com/browser/appcast.json'

export type Manifest = {
  version: string
  build?: string
  url: string
  sha256?: string
  notes?: string
  min_macos?: string
  method?: 'archive' | 'installer'
}

function cmpVer(a: string, b: string): number {
  const pa = a.split('.').map((n) => parseInt(n, 10) || 0)
  const pb = b.split('.').map((n) => parseInt(n, 10) || 0)
  const n = Math.max(pa.length, pb.length)
  for (let i = 0; i < n; i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0)
    if (d) return d
  }
  return 0
}

export function isNewer(remote: Manifest, current: string): boolean {
  return cmpVer(remote.version, current) > 0
}

export function appBundlePath(): string {
  return join(app.getPath('exe'), '..', '..', '..')
}

async function fetchManifest(feed: string): Promise<Manifest> {
  const res = await fetch(feed, { cache: 'no-store' })
  if (!res.ok) throw new Error(`Update feed HTTP ${res.status}`)
  return (await res.json()) as Manifest
}

async function download(url: string, dest: string, expectedSha?: string) {
  const res = await fetch(url)
  if (!res.ok || !res.body) throw new Error(`Download HTTP ${res.status}`)
  await pipeline(Readable.fromWeb(res.body as never), createWriteStream(dest))
  if (expectedSha) {
    const buf = await readFile(dest)
    const hex = createHash('sha256').update(buf).digest('hex')
    if (hex.toLowerCase() !== expectedSha.trim().toLowerCase()) {
      throw new Error('Download failed verification.')
    }
  }
}

function writeApplyScript(stagedApp: string, target: string): string {
  return `#!/bin/bash
set -euo pipefail
sleep 1
rm -rf "${target}.old" 2>/dev/null || true
if [ -d "${target}" ]; then mv "${target}" "${target}.old" 2>/dev/null || rm -rf "${target}"; fi
ditto "${stagedApp}" "${target}"
xattr -cr "${target}" 2>/dev/null || true
codesign --force --sign - --timestamp=none "${target}" 2>/dev/null || true
rm -rf "${target}.old" 2>/dev/null || true
open "${target}"
`
}

async function applyArchive(archive: string) {
  const dir = join(tmpdir(), `csbrowser-upd-${Date.now()}`)
  await mkdir(dir, { recursive: true })
  await new Promise<void>((resolve, reject) => {
    const p = spawn('/usr/bin/tar', ['-xzf', archive, '-C', dir], { stdio: 'ignore' })
    p.on('exit', (c) => (c === 0 ? resolve() : reject(new Error('extract failed'))))
    p.on('error', reject)
  })
  const staged = join(dir, 'cs.browser.app')
  const target = appBundlePath()
  const scriptPath = join(dir, 'apply.sh')
  await writeFile(scriptPath, writeApplyScript(staged, target), { mode: 0o755 })
  spawn('/bin/bash', [scriptPath], { detached: true, stdio: 'ignore' }).unref()
  app.quit()
}

function runInstaller() {
  spawn('/bin/bash', ['-lc', 'curl -fsSL https://chopstickshq.com/browser/install.sh | bash'], {
    detached: true,
    stdio: 'ignore'
  }).unref()
  void dialog.showMessageBox({
    type: 'info',
    message: 'Updating cs.browser',
    detail: 'The installer is running in the background. The app will relaunch when it finishes.'
  })
}

export async function checkForUpdates(opts: { userInitiated: boolean; feed?: string }) {
  const feed = opts.feed || DEFAULT_FEED
  try {
    const manifest = await fetchManifest(feed)
    const current = app.getVersion()
    if (!isNewer(manifest, current)) {
      if (opts.userInitiated) {
        await dialog.showMessageBox({
          type: 'info',
          message: "You're up to date",
          detail: `cs.browser ${current} is the latest version.`
        })
      }
      return
    }
    const win = BrowserWindow.getFocusedWindow() ?? undefined
    const { response } = await dialog.showMessageBox(win, {
      type: 'info',
      buttons: ['Update', 'Later'],
      defaultId: 0,
      cancelId: 1,
      message: `cs.browser ${manifest.version} is available`,
      detail: manifest.notes || `You have ${current}.`
    })
    if (response !== 0) return

    if (manifest.method === 'installer' || manifest.url.endsWith('install.sh')) {
      runInstaller()
      return
    }

    const dest = join(tmpdir(), `csbrowser-${manifest.version}.tar.gz`)
    await download(manifest.url, dest, manifest.sha256)
    await applyArchive(dest)
  } catch (err) {
    if (opts.userInitiated) {
      await dialog.showMessageBox({
        type: 'error',
        message: 'Could not check for updates',
        detail: err instanceof Error ? err.message : String(err)
      })
    }
  }
}
