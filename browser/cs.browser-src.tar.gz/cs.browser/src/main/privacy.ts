import { app, session } from 'electron'
import os from 'node:os'
import { hostIsTracker } from './trackers'

export function ramGB(): number {
  return Math.round(os.totalmem() / 1073741824)
}

export function applyChromiumFlags() {
  const gb = ramGB()
  app.commandLine.appendSwitch('enable-low-end-device-mode')
  app.commandLine.appendSwitch('process-per-site')
  app.commandLine.appendSwitch('js-flags', gb < 10 ? '--max-old-space-size=256' : '--max-old-space-size=512')
  app.commandLine.appendSwitch('renderer-process-limit', gb < 7 ? '2' : gb < 10 ? '3' : '6')
  app.commandLine.appendSwitch('disable-features', 'TranslateUI,MediaRouter,AutofillServerCommunication')
  app.commandLine.appendSwitch('disable-breakpad')
  app.commandLine.appendSwitch('disable-component-update')
  if (gb < 7) app.commandLine.appendSwitch('disable-gpu-compositing')
}

export function applyPrivacy(ses: Electron.Session, httpsOnly: boolean, blockTrackers: boolean) {
  ses.setPermissionRequestHandler((_wc, permission, callback) => {
    callback(['clipboard-sanitized-write', 'fullscreen', 'media', 'notifications'].includes(permission))
  })
  ses.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (details, callback) => {
    try {
      const url = new URL(details.url)
      if (httpsOnly && url.protocol === 'http:' && url.hostname !== 'localhost') {
        url.protocol = 'https:'
        callback({ redirectURL: url.toString() })
        return
      }
      if (blockTrackers && hostIsTracker(url.hostname)) {
        callback({ cancel: true })
        return
      }
    } catch { /* ignore */ }
    callback({})
  })
}

export function defaultSession() {
  return session.fromPartition('persist:cs-browser')
}

export function workspaceSession(id: string) {
  return session.fromPartition(`persist:ws-${id}`)
}
