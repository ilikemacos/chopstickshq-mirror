export const TRACKER_HOSTS = new Set([
  'doubleclick.net', 'googleadservices.com', 'googlesyndication.com',
  'google-analytics.com', 'googletagmanager.com', 'facebook.net',
  'scorecardresearch.com', 'hotjar.com', 'mixpanel.com', 'adnxs.com',
  'adsrvr.org', 'criteo.com', 'taboola.com', 'outbrain.com'
])

export function hostIsTracker(hostname: string): boolean {
  const h = hostname.toLowerCase()
  for (const t of TRACKER_HOSTS) {
    if (h === t || h.endsWith(`.${t}`)) return true
  }
  return false
}
