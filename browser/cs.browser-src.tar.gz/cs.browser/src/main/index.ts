import {
  app, BrowserWindow, ipcMain, Menu, screen, shell, nativeTheme, session
} from 'electron'
import { join } from 'node:path'
import Store from 'electron-store'
import {
  applyChromiumFlags, applyPrivacy, defaultSession, workspaceSession, ramGB
} from './privacy'
import { checkForUpdates } from './updater'

applyChromiumFlags()
app.setName('cs.browser')

type Prefs = {
  theme: 'dark' | 'light'
  compact: boolean
  sidebarCollapsed: boolean
  httpsOnly: boolean
  blockTrackers: boolean
  apiBaseURL: string
  apiModel: string
}

const store = new Store<{ prefs: Prefs; workspaces: { id: string; name: string; icon: string; accent: string }[] }>({
  defaults: {
    prefs: {
      theme: 'dark', compact: false, sidebarCollapsed: false,
      httpsOnly: true, blockTrackers: true,
      apiBaseURL: 'https://api.openai.com/v1/chat/completions',
      apiModel: 'gpt-4o-mini'
    },
    workspaces: [
      { id: 'default', name: 'Default', icon: '◎', accent: '#7eb8da' },
      { id: 'work', name: 'Work', icon: '⌘', accent: '#c4a574' },
      { id: 'play', name: 'Play', icon: '✦', accent: '#b48ead' }
    ]
  }
})

const windows = new Set<BrowserWindow>()
let compactPoll: NodeJS.Timeout | null = null
const edge = new WeakMap<BrowserWindow, boolean>()

function send(win: BrowserWindow | null, name: string, extra?: unknown) {
  win?.webContents.send('shortcut', name, extra)
}

function focused(): BrowserWindow | null {
  return BrowserWindow.getFocusedWindow()
}

function createWindow(incognito = false) {
  const prefs = store.get('prefs')
  nativeTheme.themeSource = prefs.theme
  const gb = ramGB()
  const win = new BrowserWindow({
    width: gb < 8 ? 1100 : 1440,
    height: gb < 8 ? 740 : 920,
    minWidth: 800,
    minHeight: 520,
    title: incognito ? 'cs.browser (Incognito)' : 'cs.browser',
    titleBarStyle: 'hiddenInset',
    trafficLightPosition: { x: 14, y: 14 },
    backgroundColor: prefs.theme === 'dark' ? '#1a1b1e' : '#f4f1ea',
    vibrancy: process.platform === 'darwin' ? 'under-window' : undefined,
    show: false,
    webPreferences: {
      preload: join(__dirname, '../preload/index.mjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webviewTag: true,
      spellcheck: gb >= 8,
      backgroundThrottling: true,
      session: incognito ? session.fromPartition('tmp:incognito') : defaultSession()
    }
  })
  windows.add(win)
  applyPrivacy(win.webContents.session, prefs.httpsOnly, prefs.blockTrackers)
  for (const ws of store.get('workspaces')) {
    applyPrivacy(workspaceSession(ws.id), prefs.httpsOnly, prefs.blockTrackers)
  }
  if (process.env.ELECTRON_RENDERER_URL) win.loadURL(process.env.ELECTRON_RENDERER_URL)
  else win.loadFile(join(__dirname, '../renderer/index.html'))
  win.once('ready-to-show', () => {
    win.show()
    if (incognito) send(win, 'incognito')
  })
  win.on('closed', () => windows.delete(win))
  return win
}

function startCompactTracker() {
  if (compactPoll) clearInterval(compactPoll)
  compactPoll = setInterval(() => {
    for (const win of windows) {
      if (win.isDestroyed()) continue
      const prefs = store.get('prefs')
      if (!prefs.compact) continue
      const cursor = screen.getCursorScreenPoint()
      const bounds = win.getBounds()
      const insideY = cursor.y >= bounds.y && cursor.y <= bounds.y + bounds.height
      const nearLeft = insideY && cursor.x >= bounds.x - 8 && cursor.x <= bounds.x + 28
      const over = insideY && cursor.x >= bounds.x && cursor.x <= bounds.x + 280
      const prev = edge.get(win) ?? false
      const next = nearLeft || (prev && over)
      if (next !== prev) {
        edge.set(win, next)
        win.webContents.send('compact-edge', next)
      }
    }
  }, 50)
}

function buildMenu() {
  const isMac = process.platform === 'darwin'
  const t: Electron.MenuItemConstructorOptions[] = [
    ...(isMac ? [{ role: 'appMenu' as const }] : []),
    {
      label: 'File',
      submenu: [
        { label: 'New Tab', accelerator: 'CmdOrCtrl+T', click: () => send(focused(), 'new-tab') },
        { label: 'New Window', accelerator: 'CmdOrCtrl+N', click: () => createWindow(false) },
        { label: 'New Incognito Window', accelerator: 'CmdOrCtrl+Shift+N', click: () => createWindow(true) },
        { type: 'separator' },
        { label: 'Open File…', accelerator: 'CmdOrCtrl+O', click: () => send(focused(), 'open-file') },
        { label: 'Open Location…', accelerator: 'CmdOrCtrl+L', click: () => send(focused(), 'focus-url') },
        { type: 'separator' },
        { label: 'Close Tab', accelerator: 'CmdOrCtrl+W', click: () => send(focused(), 'close-tab') },
        { label: 'Close Window', accelerator: 'CmdOrCtrl+Shift+W', role: 'close' },
        { label: 'Reopen Closed Tab', accelerator: 'CmdOrCtrl+Shift+T', click: () => send(focused(), 'reopen-tab') },
        { type: 'separator' },
        { label: 'Save Page As…', accelerator: 'CmdOrCtrl+S', click: () => send(focused(), 'save') },
        { label: 'Print…', accelerator: 'CmdOrCtrl+P', click: () => send(focused(), 'print') }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'pasteAndMatchStyle' },
        { role: 'delete' }, { role: 'selectAll' },
        { type: 'separator' },
        { label: 'Find…', accelerator: 'CmdOrCtrl+F', click: () => send(focused(), 'find') },
        { label: 'Find Next', accelerator: 'CmdOrCtrl+G', click: () => send(focused(), 'find-next') },
        { label: 'Find Previous', accelerator: 'CmdOrCtrl+Shift+G', click: () => send(focused(), 'find-prev') }
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Reload', accelerator: 'CmdOrCtrl+R', click: () => send(focused(), 'reload') },
        { label: 'Hard Reload', accelerator: 'CmdOrCtrl+Shift+R', click: () => send(focused(), 'hard-reload') },
        { label: 'Stop', accelerator: 'Escape', click: () => send(focused(), 'stop') },
        { type: 'separator' },
        { label: 'Actual Size', accelerator: 'CmdOrCtrl+0', click: () => send(focused(), 'zoom-reset') },
        { label: 'Zoom In', accelerator: 'CmdOrCtrl+Plus', click: () => send(focused(), 'zoom-in') },
        { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', click: () => send(focused(), 'zoom-out') },
        { type: 'separator' },
        { label: 'Compact Mode', accelerator: 'Alt+CmdOrCtrl+S', click: () => send(focused(), 'compact') },
        { label: 'Toggle Sidebar', accelerator: 'CmdOrCtrl+Shift+S', click: () => send(focused(), 'toggle-sidebar') },
        { label: 'cs.ai', accelerator: 'CmdOrCtrl+Shift+A', click: () => send(focused(), 'ai') },
        { label: 'Split View', accelerator: 'Alt+CmdOrCtrl+V', click: () => send(focused(), 'split') },
        { type: 'separator' },
        { role: 'togglefullscreen' },
        { label: 'Developer Tools', accelerator: 'Alt+CmdOrCtrl+I', click: () => send(focused(), 'devtools') },
        { label: 'JavaScript Console', accelerator: 'Alt+CmdOrCtrl+J', click: () => send(focused(), 'devtools') }
      ]
    },
    {
      label: 'History',
      submenu: [
        { label: 'Back', accelerator: 'CmdOrCtrl+[', click: () => send(focused(), 'back') },
        { label: 'Forward', accelerator: 'CmdOrCtrl+]', click: () => send(focused(), 'forward') },
        { label: 'Home', accelerator: 'Alt+Home', click: () => send(focused(), 'home') },
        { type: 'separator' },
        { label: 'Reopen Closed Tab', accelerator: 'CmdOrCtrl+Shift+T', click: () => send(focused(), 'reopen-tab') },
        { label: 'Show Full History', accelerator: 'CmdOrCtrl+Y', click: () => send(focused(), 'history') }
      ]
    },
    {
      label: 'Bookmarks',
      submenu: [
        { label: 'Bookmark This Tab…', accelerator: 'CmdOrCtrl+D', click: () => send(focused(), 'bookmark') },
        { label: 'Bookmark All Tabs…', accelerator: 'CmdOrCtrl+Shift+D', click: () => send(focused(), 'bookmark-all') },
        { label: 'Bookmark Manager', accelerator: 'Alt+CmdOrCtrl+B', click: () => send(focused(), 'bookmarks') }
      ]
    },
    {
      label: 'Window',
      submenu: [
        { role: 'minimize' }, { role: 'zoom' },
        { type: 'separator' },
        { label: 'Next Tab', accelerator: 'Control+Tab', click: () => send(focused(), 'next-tab') },
        { label: 'Previous Tab', accelerator: 'Control+Shift+Tab', click: () => send(focused(), 'prev-tab') },
        { label: 'Select Next Tab', accelerator: 'Alt+CmdOrCtrl+Right', click: () => send(focused(), 'next-tab') },
        { label: 'Select Previous Tab', accelerator: 'Alt+CmdOrCtrl+Left', click: () => send(focused(), 'prev-tab') },
        { type: 'separator' },
        ...[1, 2, 3, 4, 5, 6, 7, 8].map((n) => ({
          label: `Tab ${n}`,
          accelerator: `CmdOrCtrl+${n}`,
          click: () => send(focused(), 'tab-n', n)
        })),
        { label: 'Last Tab', accelerator: 'CmdOrCtrl+9', click: () => send(focused(), 'tab-last') },
        { type: 'separator' },
        { role: 'front' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        { label: 'cs.browser Help', click: () => send(focused(), 'home') },
        { type: 'separator' },
        {
          label: 'Check for Updates…',
          click: () => { void checkForUpdates({ userInitiated: true }) }
        }
      ]
    }
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(t))
}

app.whenReady().then(() => {
  buildMenu()
  createWindow()
  startCompactTracker()
  setTimeout(() => { void checkForUpdates({ userInitiated: false }) }, 8000)
  setInterval(() => { void checkForUpdates({ userInitiated: false }) }, 12 * 60 * 60 * 1000)
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})

ipcMain.handle('prefs:get', () => store.get('prefs'))
ipcMain.handle('prefs:set', (_e, patch: Partial<Prefs>) => {
  const next = { ...store.get('prefs'), ...patch }
  store.set('prefs', next)
  nativeTheme.themeSource = next.theme
  applyPrivacy(defaultSession(), next.httpsOnly, next.blockTrackers)
  return next
})
ipcMain.handle('workspaces:get', () => store.get('workspaces'))
ipcMain.handle('workspaces:set', (_e, list) => {
  store.set('workspaces', list)
  return list
})
ipcMain.handle('open-external', (_e, url: string) => shell.openExternal(url))
ipcMain.handle('ai:complete', async (_e, payload: { messages: { role: string; content: string }[]; apiKey: string }) => {
  const prefs = store.get('prefs')
  const res = await fetch(prefs.apiBaseURL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${payload.apiKey}` },
    body: JSON.stringify({ model: prefs.apiModel, messages: payload.messages, temperature: 0.4 })
  })
  if (!res.ok) throw new Error((await res.text()).slice(0, 400))
  const json = (await res.json()) as { choices?: { message?: { content?: string } }[] }
  return json.choices?.[0]?.message?.content ?? ''
})
