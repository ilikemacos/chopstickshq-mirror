# cs.browser

Chromium desktop browser (Zen-like chrome) with **cs.ai**. Ships as a real
`.app` — not WebKit.

**Landing:** [chopstickshq.com/browser](https://chopstickshq.com/browser)

The app checks [appcast.json](https://chopstickshq.com/browser/appcast.json) on launch
and from **Help → Check for Updates**.

## Install

```sh
curl -fsSL https://chopstickshq.com/browser/install.sh | bash
```

That is the only supported install method.

| | |
|---|---|
| Engine | Chromium |
| Sudo | Never |
| Install | `~/Applications/cs.browser.app` |
| RAM | More than 6GB (8GB Air: process limits + low-end Chromium mode) |
| Telemetry | None |

## Shortcuts (Chrome-style)

| Shortcut | Action |
| --- | --- |
| ⌘T / ⌘W | New / close tab |
| ⌘⇧T | Reopen closed tab |
| ⌘N / ⌘⇧N | New window / incognito |
| ⌘⇧W | Close window |
| ⌘L | Address bar |
| ⌘R / ⌘⇧R | Reload / hard reload |
| Esc | Stop |
| ⌘[ ⌘] | Back / forward |
| ⌘F ⌘G ⌘⇧G | Find / next / previous |
| ⌘+ ⌘- ⌘0 | Zoom |
| ⌘S / ⌘P | Save page / print |
| ⌃Tab / ⌃⇧Tab | Next / previous tab |
| ⌘1–8 / ⌘9 | Tab n / last tab |
| ⌥⌘← / ⌥⌘→ | Previous / next tab |
| ⌘D / ⌘⇧D | Bookmark tab / all |
| ⌘Y | History |
| ⌥⌘I | Developer tools |
| ⌥⌘S | Compact mode |
| ⌘⇧A | cs.ai |
| ⌥⌘V | Split view |
| Alt-click link | Glance |

⌘S is **Save Page** (same as Chrome). Compact mode is **⌥⌘S**.
