#!/usr/bin/env swift
import AppKit

let outDir = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "Resources/AppIcon.iconset"
let fm = FileManager.default
try? fm.createDirectory(atPath: outDir, withIntermediateDirectories: true)

let sizes: [(Int, String)] = [
    (16, "icon_16x16.png"),
    (32, "icon_16x16@2x.png"),
    (32, "icon_32x32.png"),
    (64, "icon_32x32@2x.png"),
    (128, "icon_128x128.png"),
    (256, "icon_128x128@2x.png"),
    (256, "icon_256x256.png"),
    (512, "icon_256x256@2x.png"),
    (512, "icon_512x512.png"),
    (1024, "icon_512x512@2x.png"),
]

func drawIcon(size: Int) -> NSImage {
    let s = CGFloat(size)
    let img = NSImage(size: NSSize(width: s, height: s))
    img.lockFocus()
    defer { img.unlockFocus() }
    let rect = NSRect(x: 0, y: 0, width: s, height: s)
    let bg = NSBezierPath(roundedRect: rect.insetBy(dx: s * 0.06, dy: s * 0.06),
                          xRadius: s * 0.22, yRadius: s * 0.22)
    NSColor(calibratedRed: 0.10, green: 0.11, blue: 0.12, alpha: 1).setFill()
    bg.fill()
    let side = NSBezierPath(roundedRect: NSRect(x: s * 0.18, y: s * 0.22, width: s * 0.18, height: s * 0.56),
                            xRadius: s * 0.04, yRadius: s * 0.04)
    NSColor(calibratedRed: 0.49, green: 0.72, blue: 0.85, alpha: 1).setFill()
    side.fill()
    let page = NSBezierPath(roundedRect: NSRect(x: s * 0.40, y: s * 0.22, width: s * 0.42, height: s * 0.56),
                            xRadius: s * 0.05, yRadius: s * 0.05)
    NSColor(calibratedWhite: 0.92, alpha: 0.9).setFill()
    page.fill()
    return img
}

for (px, name) in sizes {
    let img = drawIcon(size: px)
    guard let tiff = img.tiffRepresentation,
          let rep = NSBitmapImageRep(data: tiff),
          let png = rep.representation(using: .png, properties: [:]) else { continue }
    let path = (outDir as NSString).appendingPathComponent(name)
    try? png.write(to: URL(fileURLWithPath: path))
}
